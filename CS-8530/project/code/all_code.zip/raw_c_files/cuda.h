#ifndef _CUDA1_H_
#define _CUDA1_H_

// header to connect cpp to cuda
void resize();
void greyscale();
void hash();
#endif